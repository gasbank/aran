//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by resource.rc
//
#define IDD_ABOUT                       101
#define IDD_SETTINGS                    102
#define IDC_GEOMETRY                    1001
#define IDC_MATERIALS                   1002
#define IDC_GEOMETRY2                   1003
#define IDC_FRAMERATE                   1004
#define IDC_CREDITS                     1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        103
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
